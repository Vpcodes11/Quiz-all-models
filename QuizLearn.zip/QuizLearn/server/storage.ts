import { type User, type InsertUser, type Quiz, type InsertQuiz, type Question, type InsertQuestion, type QuizAttempt, type InsertQuizAttempt } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStats(userId: string, stats: { totalQuizzesTaken?: number; averageScore?: number; currentStreak?: number }): Promise<User | undefined>;

  // Quiz methods
  getAllQuizzes(): Promise<Quiz[]>;
  getQuizById(id: string): Promise<Quiz | undefined>;
  getQuizzesByType(type: string): Promise<Quiz[]>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;

  // Question methods
  getQuestionsByQuizId(quizId: string): Promise<Question[]>;
  createQuestion(question: InsertQuestion): Promise<Question>;

  // Quiz Attempt methods
  createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;
  getUserQuizAttempts(userId: string): Promise<QuizAttempt[]>;
  getQuizAttemptsByUser(userId: string, limit?: number): Promise<QuizAttempt[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private quizzes: Map<string, Quiz> = new Map();
  private questions: Map<string, Question> = new Map();
  private quizAttempts: Map<string, QuizAttempt> = new Map();

  constructor() {
    this.initializeTestData();
  }

  private initializeTestData() {
    // Create sample quizzes
    const quickQuiz: Quiz = {
      id: "quick-1",
      title: "Quick MCQ",
      description: "5 random questions • 2 mins",
      type: "quick",
      timeLimit: 2,
      totalQuestions: 5,
      isActive: true,
      createdAt: new Date(),
    };

    const mockTest: Quiz = {
      id: "mock-1",
      title: "Mock Test",
      description: "25 questions • 30 mins",
      type: "mock",
      timeLimit: 30,
      totalQuestions: 25,
      isActive: true,
      createdAt: new Date(),
    };

    const practiceQuiz: Quiz = {
      id: "practice-1",
      title: "Practice Mode",
      description: "Unlimited questions • No timer",
      type: "practice",
      timeLimit: null,
      totalQuestions: 10,
      isActive: true,
      createdAt: new Date(),
    };

    this.quizzes.set(quickQuiz.id, quickQuiz);
    this.quizzes.set(mockTest.id, mockTest);
    this.quizzes.set(practiceQuiz.id, practiceQuiz);

    // Create sample questions for quick quiz
    const sampleQuestions: Question[] = [
      {
        id: "q1",
        quizId: "quick-1",
        questionText: "What is the primary purpose of data structures in computer science?",
        options: [
          { text: "To organize and store data efficiently", id: 0 },
          { text: "To create graphical user interfaces", id: 1 },
          { text: "To manage network connections", id: 2 },
          { text: "To compile programming languages", id: 3 }
        ],
        correctAnswer: 0,
        explanation: "Data structures are designed to organize and store data in ways that enable efficient access and modification.",
        difficulty: "medium",
        createdAt: new Date(),
      },
      {
        id: "q2",
        quizId: "quick-1",
        questionText: "Which of the following is NOT a programming paradigm?",
        options: [
          { text: "Object-Oriented Programming", id: 0 },
          { text: "Functional Programming", id: 1 },
          { text: "Database Programming", id: 2 },
          { text: "Procedural Programming", id: 3 }
        ],
        correctAnswer: 2,
        explanation: "Database Programming is not a programming paradigm, but rather a domain or application area.",
        difficulty: "easy",
        createdAt: new Date(),
      },
      {
        id: "q3",
        quizId: "quick-1",
        questionText: "What does CPU stand for?",
        options: [
          { text: "Central Processing Unit", id: 0 },
          { text: "Computer Processing Unit", id: 1 },
          { text: "Central Program Unit", id: 2 },
          { text: "Computer Program Unit", id: 3 }
        ],
        correctAnswer: 0,
        explanation: "CPU stands for Central Processing Unit, which is the main component that executes instructions.",
        difficulty: "easy",
        createdAt: new Date(),
      },
      {
        id: "q4",
        quizId: "quick-1",
        questionText: "Which sorting algorithm has the best average-case time complexity?",
        options: [
          { text: "Bubble Sort", id: 0 },
          { text: "Selection Sort", id: 1 },
          { text: "Merge Sort", id: 2 },
          { text: "Insertion Sort", id: 3 }
        ],
        correctAnswer: 2,
        explanation: "Merge Sort has O(n log n) time complexity in all cases, making it efficient for large datasets.",
        difficulty: "hard",
        createdAt: new Date(),
      },
      {
        id: "q5",
        quizId: "quick-1",
        questionText: "What is the purpose of version control systems like Git?",
        options: [
          { text: "To compile code", id: 0 },
          { text: "To track changes in code over time", id: 1 },
          { text: "To execute programs", id: 2 },
          { text: "To debug applications", id: 3 }
        ],
        correctAnswer: 1,
        explanation: "Version control systems track changes in code, allowing developers to collaborate and maintain history.",
        difficulty: "medium",
        createdAt: new Date(),
      }
    ];

    sampleQuestions.forEach(q => this.questions.set(q.id, q));
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      totalQuizzesTaken: 0,
      averageScore: 0,
      currentStreak: 0,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStats(userId: string, stats: { totalQuizzesTaken?: number; averageScore?: number; currentStreak?: number }): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;

    const updatedUser = { ...user, ...stats };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async getAllQuizzes(): Promise<Quiz[]> {
    return Array.from(this.quizzes.values()).filter(quiz => quiz.isActive);
  }

  async getQuizById(id: string): Promise<Quiz | undefined> {
    return this.quizzes.get(id);
  }

  async getQuizzesByType(type: string): Promise<Quiz[]> {
    return Array.from(this.quizzes.values()).filter(quiz => quiz.type === type && quiz.isActive);
  }

  async createQuiz(insertQuiz: InsertQuiz): Promise<Quiz> {
    const id = randomUUID();
    const quiz: Quiz = { 
      ...insertQuiz, 
      id,
      isActive: true,
      createdAt: new Date()
    };
    this.quizzes.set(id, quiz);
    return quiz;
  }

  async getQuestionsByQuizId(quizId: string): Promise<Question[]> {
    return Array.from(this.questions.values()).filter(question => question.quizId === quizId);
  }

  async createQuestion(insertQuestion: InsertQuestion): Promise<Question> {
    const id = randomUUID();
    const question: Question = { 
      ...insertQuestion, 
      id,
      createdAt: new Date()
    };
    this.questions.set(id, question);
    return question;
  }

  async createQuizAttempt(insertAttempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const id = randomUUID();
    const attempt: QuizAttempt = { 
      ...insertAttempt, 
      id,
      completedAt: new Date()
    };
    this.quizAttempts.set(id, attempt);
    return attempt;
  }

  async getUserQuizAttempts(userId: string): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values()).filter(attempt => attempt.userId === userId);
  }

  async getQuizAttemptsByUser(userId: string, limit?: number): Promise<QuizAttempt[]> {
    const attempts = Array.from(this.quizAttempts.values())
      .filter(attempt => attempt.userId === userId)
      .sort((a, b) => new Date(b.completedAt!).getTime() - new Date(a.completedAt!).getTime());
    
    return limit ? attempts.slice(0, limit) : attempts;
  }
}

export const storage = new MemStorage();
