import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertQuizAttemptSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  // Quiz routes
  app.get("/api/quizzes", async (req, res) => {
    try {
      const quizzes = await storage.getAllQuizzes();
      res.json(quizzes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch quizzes" });
    }
  });

  app.get("/api/quizzes/:id", async (req, res) => {
    try {
      const quiz = await storage.getQuizById(req.params.id);
      if (!quiz) {
        return res.status(404).json({ error: "Quiz not found" });
      }
      res.json(quiz);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch quiz" });
    }
  });

  app.get("/api/quizzes/type/:type", async (req, res) => {
    try {
      const quizzes = await storage.getQuizzesByType(req.params.type);
      res.json(quizzes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch quizzes by type" });
    }
  });

  // Question routes
  app.get("/api/quizzes/:id/questions", async (req, res) => {
    try {
      const questions = await storage.getQuestionsByQuizId(req.params.id);
      res.json(questions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch questions" });
    }
  });

  // Quiz attempt routes
  app.post("/api/quiz-attempts", async (req, res) => {
    try {
      const attemptData = insertQuizAttemptSchema.parse(req.body);
      const attempt = await storage.createQuizAttempt(attemptData);
      
      // Update user stats
      const userAttempts = await storage.getUserQuizAttempts(attemptData.userId);
      const totalQuizzes = userAttempts.length;
      const averageScore = Math.round(userAttempts.reduce((sum, att) => sum + att.score, 0) / totalQuizzes);
      
      await storage.updateUserStats(attemptData.userId, {
        totalQuizzesTaken: totalQuizzes,
        averageScore: averageScore,
      });

      res.json(attempt);
    } catch (error) {
      res.status(400).json({ error: "Invalid quiz attempt data" });
    }
  });

  app.get("/api/users/:userId/quiz-attempts", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const attempts = await storage.getQuizAttemptsByUser(req.params.userId, limit);
      res.json(attempts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch quiz attempts" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
