import { useQuery } from "@tanstack/react-query";
import { TrendingUp, Calendar, Trophy, Clock } from "lucide-react";
import type { QuizAttempt } from "@shared/schema";

export default function Progress() {
  // Mock data for demonstration
  const mockStats = {
    totalQuizzes: 23,
    averageScore: 87,
    streak: 5,
    timeSpent: 145, // minutes
  };

  const mockRecentActivity: Array<{
    id: string;
    quizTitle: string;
    score: number;
    date: string;
    type: "quick" | "mock" | "practice";
  }> = [
    {
      id: "1",
      quizTitle: "Quick MCQ",
      score: 92,
      date: "2 hours ago",
      type: "quick",
    },
    {
      id: "2",
      quizTitle: "Mock Test",
      score: 76,
      date: "Yesterday",
      type: "mock",
    },
    {
      id: "3",
      quizTitle: "Practice Mode",
      score: 88,
      date: "2 days ago",
      type: "practice",
    },
  ];

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-ios-green";
    if (score >= 80) return "text-ios-blue";
    if (score >= 70) return "text-orange-500";
    return "text-ios-red";
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "quick":
        return "⚡";
      case "mock":
        return "📋";
      case "practice":
        return "🏋️";
      default:
        return "📝";
    }
  };

  return (
    <div className="min-h-screen bg-ios-gray pb-20">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="px-4 py-3">
          <h1 className="text-xl font-bold text-ios-dark text-center" data-testid="text-progress-title">Your Progress</h1>
        </div>
      </header>

      <div className="px-4 py-4 space-y-6">
        {/* Overall Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-xl p-4 text-center shadow-sm">
            <div className="flex items-center justify-center mb-2">
              <Trophy className="h-5 w-5 text-ios-blue mr-2" />
            </div>
            <div className="text-2xl font-bold text-ios-blue" data-testid="text-total-quizzes">{mockStats.totalQuizzes}</div>
            <div className="text-xs text-gray-600 mt-1">Total Quizzes</div>
          </div>
          
          <div className="bg-white rounded-xl p-4 text-center shadow-sm">
            <div className="flex items-center justify-center mb-2">
              <TrendingUp className="h-5 w-5 text-ios-green mr-2" />
            </div>
            <div className="text-2xl font-bold text-ios-green" data-testid="text-average-score">{mockStats.averageScore}%</div>
            <div className="text-xs text-gray-600 mt-1">Average Score</div>
          </div>
          
          <div className="bg-white rounded-xl p-4 text-center shadow-sm">
            <div className="flex items-center justify-center mb-2">
              <Calendar className="h-5 w-5 text-orange-500 mr-2" />
            </div>
            <div className="text-2xl font-bold text-orange-500" data-testid="text-streak">{mockStats.streak}</div>
            <div className="text-xs text-gray-600 mt-1">Day Streak</div>
          </div>
          
          <div className="bg-white rounded-xl p-4 text-center shadow-sm">
            <div className="flex items-center justify-center mb-2">
              <Clock className="h-5 w-5 text-purple-500 mr-2" />
            </div>
            <div className="text-2xl font-bold text-purple-500" data-testid="text-time-spent">{mockStats.timeSpent}m</div>
            <div className="text-xs text-gray-600 mt-1">Time Spent</div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <h3 className="font-semibold text-ios-dark mb-4" data-testid="text-recent-activity">Recent Activity</h3>
          
          <div className="space-y-3">
            {mockRecentActivity.map((activity, index) => (
              <div key={activity.id} className="flex items-center justify-between" data-testid={`activity-${index}`}>
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-ios-blue/10 rounded-full flex items-center justify-center mr-3 text-sm">
                    {getActivityIcon(activity.type)}
                  </div>
                  <div>
                    <div className="font-medium text-sm" data-testid={`activity-title-${index}`}>{activity.quizTitle}</div>
                    <div className="text-xs text-gray-600" data-testid={`activity-date-${index}`}>{activity.date}</div>
                  </div>
                </div>
                <span className={`font-semibold text-sm ${getScoreColor(activity.score)}`} data-testid={`activity-score-${index}`}>
                  {activity.score}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Performance Chart Placeholder */}
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <h3 className="font-semibold text-ios-dark mb-4" data-testid="text-weekly-performance">Weekly Performance</h3>
          
          <div className="text-center py-8">
            <img 
              src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=200" 
              alt="Data analytics and performance charts on mobile screen" 
              className="w-full h-32 object-cover rounded-lg opacity-50 mb-4"
              data-testid="img-performance-chart"
            />
            <p className="text-gray-500 text-sm" data-testid="text-chart-placeholder">Performance chart will be displayed here</p>
            <p className="text-gray-400 text-xs mt-2">Feature coming soon!</p>
          </div>
        </div>

        {/* Study Streak */}
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <h3 className="font-semibold text-ios-dark mb-4" data-testid="text-study-streak">Study Streak</h3>
          
          <div className="text-center">
            <div className="text-3xl mb-2">🔥</div>
            <div className="text-xl font-bold text-orange-500 mb-2" data-testid="text-streak-days">{mockStats.streak} Days</div>
            <p className="text-sm text-gray-600 mb-4">Keep it up! You're on a roll!</p>
            
            <div className="flex justify-center space-x-2">
              {[1, 2, 3, 4, 5, 6, 7].map((day) => (
                <div
                  key={day}
                  className={`w-6 h-6 rounded-full ${
                    day <= mockStats.streak ? "bg-orange-500" : "bg-gray-200"
                  }`}
                  data-testid={`streak-day-${day}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
