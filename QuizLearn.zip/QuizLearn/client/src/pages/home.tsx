import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Bell, UserCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import QuizCard from "@/components/quiz-card";
import StatsGrid from "@/components/stats-grid";
import type { Quiz } from "@shared/schema";

export default function Home() {
  const [, navigate] = useLocation();
  
  const { data: quizzes = [], isLoading } = useQuery<Quiz[]>({
    queryKey: ["/api/quizzes"],
  });

  return (
    <div className="min-h-screen pb-20 bg-ios-gray">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-ios-dark" data-testid="app-title">CDS Quiz</h1>
            <div className="flex items-center space-x-3">
              <Button 
                variant="ghost" 
                size="icon" 
                className="p-2 rounded-full bg-ios-gray hover:bg-gray-200"
                data-testid="button-notifications"
              >
                <Bell className="h-5 w-5 text-ios-blue" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="p-2 rounded-full bg-ios-gray hover:bg-gray-200"
                data-testid="button-profile"
              >
                <UserCircle className="h-6 w-6 text-ios-blue" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Welcome Section */}
      <section className="px-4 py-6 bg-gradient-to-br from-ios-blue to-blue-600 text-white">
        <div className="text-center">
          <div className="mb-4">
            <img 
              src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=200" 
              alt="Students collaborating with mobile devices" 
              className="w-full h-32 object-cover rounded-xl opacity-90"
              data-testid="img-hero"
            />
          </div>
          <h2 className="text-xl font-bold mb-2" data-testid="text-welcome">Welcome back, Student!</h2>
          <p className="text-blue-100 text-sm" data-testid="text-motivation">Ready to test your knowledge today?</p>
          <div className="mt-4 bg-white/20 rounded-lg p-3">
            <div className="flex justify-between items-center text-sm">
              <span>Weekly Progress</span>
              <span data-testid="text-weekly-progress">4/7 days</span>
            </div>
            <div className="w-full bg-white/20 rounded-full h-2 mt-2">
              <div className="bg-white h-2 rounded-full" style={{ width: "57%" }} data-testid="progress-weekly"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Stats */}
      <StatsGrid />

      {/* Quiz Options */}
      <section className="px-4 py-2">
        <h3 className="text-lg font-semibold text-ios-dark mb-4" data-testid="text-choose-quiz">Choose Your Quiz</h3>
        
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-xl p-4 animate-pulse">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gray-200 rounded-xl mr-4"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {quizzes.map((quiz) => (
              <QuizCard
                key={quiz.id}
                quiz={quiz}
                onStartQuiz={() => navigate(`/quiz/${quiz.id}`)}
              />
            ))}
          </div>
        )}
      </section>

      {/* Recent Activity */}
      <section className="px-4 py-4">
        <h3 className="text-lg font-semibold text-ios-dark mb-4" data-testid="text-recent-activity">Recent Activity</h3>
        
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <div className="text-center py-8 text-gray-500">
            <p data-testid="text-no-activity">No recent activity</p>
            <p className="text-sm mt-2">Take your first quiz to see your progress!</p>
          </div>
        </div>
      </section>
    </div>
  );
}
