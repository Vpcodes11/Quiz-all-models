import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import QuestionCard from "@/components/question-card";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import type { Quiz, Question } from "@shared/schema";

export default function Quiz() {
  const { quizId } = useParams();
  const [, navigate] = useLocation();
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [quizStarted, setQuizStarted] = useState(false);

  const { data: quiz } = useQuery<Quiz>({
    queryKey: ["/api/quizzes", quizId],
  });

  const { data: questions = [] } = useQuery<Question[]>({
    queryKey: ["/api/quizzes", quizId, "questions"],
  });

  const submitQuizMutation = useMutation({
    mutationFn: async (attemptData: any) => {
      const response = await apiRequest("POST", "/api/quiz-attempts", attemptData);
      return response.json();
    },
    onSuccess: (attempt) => {
      navigate(`/results/${attempt.id}`);
    },
  });

  useEffect(() => {
    if (quiz?.timeLimit && quizStarted) {
      setTimeLeft(quiz.timeLimit * 60); // Convert to seconds
    }
  }, [quiz, quizStarted]);

  useEffect(() => {
    if (timeLeft === null || timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev && prev <= 1) {
          handleSubmitQuiz();
          return 0;
        }
        return prev ? prev - 1 : null;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerSelect = (questionId: string, answerIndex: number) => {
    setAnswers((prev) => ({ ...prev, [questionId]: answerIndex }));
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else {
      handleSubmitQuiz();
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((prev) => prev - 1);
    }
  };

  const handleSubmitQuiz = () => {
    if (!quiz || !questions.length) return;

    const correctAnswers = questions.reduce((count, question) => {
      return answers[question.id] === question.correctAnswer ? count + 1 : count;
    }, 0);

    const score = Math.round((correctAnswers / questions.length) * 100);
    const timeSpent = quiz.timeLimit ? (quiz.timeLimit * 60) - (timeLeft || 0) : null;

    submitQuizMutation.mutate({
      userId: "demo-user", // In real app, get from auth context
      quizId: quiz.id,
      score,
      totalQuestions: questions.length,
      correctAnswers,
      timeSpent,
      answers: Object.entries(answers).map(([questionId, answerIndex]) => ({
        questionId,
        selectedAnswer: answerIndex,
        isCorrect: questions.find(q => q.id === questionId)?.correctAnswer === answerIndex
      }))
    });
  };

  const startQuiz = () => {
    setQuizStarted(true);
  };

  if (!quiz || !questions.length) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-ios-blue mx-auto mb-4"></div>
          <p className="text-gray-600" data-testid="text-loading">Loading Quiz...</p>
        </div>
      </div>
    );
  }

  if (!quizStarted) {
    return (
      <div className="min-h-screen bg-ios-gray px-4 py-8">
        <div className="max-w-md mx-auto">
          <div className="bg-white rounded-xl p-6 shadow-sm text-center">
            <h1 className="text-2xl font-bold text-ios-dark mb-2" data-testid="text-quiz-title">{quiz.title}</h1>
            <p className="text-gray-600 mb-6" data-testid="text-quiz-description">{quiz.description}</p>
            
            <div className="space-y-3 text-sm text-gray-600 mb-8">
              <div className="flex justify-between">
                <span>Questions:</span>
                <span data-testid="text-total-questions">{questions.length}</span>
              </div>
              {quiz.timeLimit && (
                <div className="flex justify-between">
                  <span>Time Limit:</span>
                  <span data-testid="text-time-limit">{quiz.timeLimit} minutes</span>
                </div>
              )}
            </div>

            <Button 
              onClick={startQuiz}
              className="w-full bg-ios-blue hover:bg-blue-600 text-white py-3 rounded-xl font-medium"
              data-testid="button-start-quiz"
            >
              Start Quiz
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen bg-ios-gray pb-4">
      {/* Quiz Header */}
      <div className="bg-white shadow-sm sticky top-0 z-50">
        <div className="px-4 py-3">
          <div className="flex justify-between items-center text-sm">
            <span className="font-medium" data-testid="text-question-counter">
              Question {currentQuestionIndex + 1} of {questions.length}
            </span>
            {timeLeft !== null && (
              <div className="flex items-center text-ios-blue font-medium">
                <Clock className="h-4 w-4 mr-1" />
                <span data-testid="text-time-remaining">{formatTime(timeLeft)}</span>
              </div>
            )}
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
            <div 
              className="bg-ios-blue h-2 rounded-full transition-all duration-300" 
              style={{ width: `${progress}%` }}
              data-testid="progress-quiz"
            />
          </div>
        </div>
      </div>

      {/* Question */}
      <div className="px-4 py-4">
        <QuestionCard
          question={currentQuestion}
          selectedAnswer={answers[currentQuestion.id]}
          onAnswerSelect={(answerIndex) => handleAnswerSelect(currentQuestion.id, answerIndex)}
        />
      </div>

      {/* Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-4">
        <div className="flex justify-between">
          <Button
            onClick={handlePreviousQuestion}
            disabled={currentQuestionIndex === 0}
            variant="ghost"
            className="flex items-center px-6 py-3 text-ios-blue font-medium disabled:opacity-50"
            data-testid="button-previous"
          >
            <ChevronLeft className="h-4 w-4 mr-2" />
            Previous
          </Button>
          
          <Button
            onClick={handleNextQuestion}
            disabled={answers[currentQuestion.id] === undefined}
            className="flex items-center px-6 py-3 bg-ios-blue hover:bg-blue-600 text-white font-medium rounded-xl disabled:opacity-50"
            data-testid="button-next"
          >
            {currentQuestionIndex === questions.length - 1 ? "Finish" : "Next"}
            <ChevronRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}
