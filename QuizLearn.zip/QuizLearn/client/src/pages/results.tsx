import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Trophy, RotateCcw, Eye, Home, CheckCircle, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { QuizAttempt, Quiz, Question } from "@shared/schema";

export default function Results() {
  const { attemptId } = useParams();
  const [, navigate] = useLocation();

  // In a real app, you'd fetch the attempt by ID
  // For now, we'll simulate the results
  const mockAttempt: QuizAttempt = {
    id: attemptId || "",
    userId: "demo-user",
    quizId: "quick-1",
    score: 85,
    totalQuestions: 5,
    correctAnswers: 4,
    timeSpent: 120,
    answers: [
      { questionId: "q1", selectedAnswer: 0, isCorrect: true },
      { questionId: "q2", selectedAnswer: 1, isCorrect: true },
      { questionId: "q3", selectedAnswer: 2, isCorrect: false },
      { questionId: "q4", selectedAnswer: 2, isCorrect: true },
      { questionId: "q5", selectedAnswer: 1, isCorrect: true },
    ],
    completedAt: new Date(),
  };

  const getPerformanceLevel = (score: number) => {
    if (score >= 90) return { level: "Excellent Performance!", message: "Outstanding work! You're mastering the material.", color: "text-ios-green" };
    if (score >= 80) return { level: "Great Job!", message: "You're doing great! Keep up the good work.", color: "text-ios-blue" };
    if (score >= 70) return { level: "Good Effort!", message: "Nice work! A little more practice will help.", color: "text-orange-500" };
    if (score >= 60) return { level: "Keep Practicing!", message: "You're on the right track. Keep studying!", color: "text-orange-600" };
    return { level: "More Study Needed", message: "Don't give up! Review the material and try again.", color: "text-ios-red" };
  };

  const performance = getPerformanceLevel(mockAttempt.score);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-ios-gray pb-20">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="px-4 py-3">
          <h1 className="text-xl font-bold text-ios-dark text-center" data-testid="text-results-title">Quiz Results</h1>
        </div>
      </header>

      <div className="px-4 py-4">
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          {/* Score Display */}
          <div className="text-center py-8 px-4">
            <img 
              src="https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=200" 
              alt="Student celebrating quiz completion on mobile" 
              className="w-24 h-24 object-cover rounded-full mx-auto mb-4"
              data-testid="img-celebration"
            />
            
            <h2 className="text-2xl font-bold text-ios-dark mb-2" data-testid="text-quiz-completed">Quiz Completed!</h2>
            <div className={`text-4xl font-bold mb-2 ${performance.color}`} data-testid="text-score">{mockAttempt.score}%</div>
            <p className="text-gray-600 mb-4" data-testid="text-score-details">
              You got <span className="font-semibold">{mockAttempt.correctAnswers}</span> out of <span className="font-semibold">{mockAttempt.totalQuestions}</span> questions correct
            </p>
            
            {mockAttempt.timeSpent && (
              <p className="text-sm text-gray-500 mb-4" data-testid="text-time-spent">
                Time taken: {formatTime(mockAttempt.timeSpent)}
              </p>
            )}
            
            {/* Performance Indicator */}
            <div className="bg-ios-green/10 rounded-xl p-4 mb-6">
              <div className="flex items-center justify-center">
                <Trophy className="h-5 w-5 text-ios-green mr-2" />
                <span className={`font-semibold ${performance.color}`} data-testid="text-performance-level">{performance.level}</span>
              </div>
              <p className="text-sm text-gray-600 mt-2" data-testid="text-performance-message">{performance.message}</p>
            </div>
          </div>

          {/* Detailed Results */}
          <div className="px-4 pb-4">
            <h3 className="font-semibold text-ios-dark mb-3" data-testid="text-question-breakdown">Question Breakdown</h3>
            <div className="space-y-3">
              {mockAttempt.answers.map((answer, index) => (
                <div key={answer.questionId} className="flex items-center justify-between py-2" data-testid={`result-question-${index + 1}`}>
                  <span className="text-sm">Question {index + 1}</span>
                  {answer.isCorrect ? (
                    <CheckCircle className="h-5 w-5 text-ios-green" data-testid={`icon-correct-${index + 1}`} />
                  ) : (
                    <XCircle className="h-5 w-5 text-ios-red" data-testid={`icon-incorrect-${index + 1}`} />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="px-4 py-4 bg-ios-gray border-t">
            <div className="space-y-3">
              <Button 
                onClick={() => navigate(`/quiz/${mockAttempt.quizId}`)}
                className="w-full py-3 bg-ios-blue hover:bg-blue-600 text-white font-medium rounded-xl"
                data-testid="button-retake"
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                Retake Quiz
              </Button>
              
              <Button 
                variant="outline"
                onClick={() => {
                  // In real app, navigate to detailed review
                  navigate("/");
                }}
                className="w-full py-3 border-ios-blue text-ios-blue hover:bg-ios-blue/5 font-medium rounded-xl"
                data-testid="button-review"
              >
                <Eye className="h-4 w-4 mr-2" />
                Review Answers
              </Button>
              
              <Button 
                variant="ghost"
                onClick={() => navigate("/")}
                className="w-full py-3 text-gray-600 hover:bg-gray-100 font-medium"
                data-testid="button-home"
              >
                <Home className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
