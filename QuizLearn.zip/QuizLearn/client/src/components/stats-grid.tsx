export default function StatsGrid() {
  const stats = [
    { value: "23", label: "Quizzes Taken", color: "text-ios-blue" },
    { value: "87%", label: "Avg Score", color: "text-ios-green" },
    { value: "5", label: "Day Streak", color: "text-orange-500" },
  ];

  return (
    <section className="px-4 py-4">
      <div className="grid grid-cols-3 gap-3">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl p-4 text-center shadow-sm">
            <div className={`text-2xl font-bold ${stat.color}`} data-testid={`stat-value-${index}`}>
              {stat.value}
            </div>
            <div className="text-xs text-gray-600 mt-1" data-testid={`stat-label-${index}`}>
              {stat.label}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
