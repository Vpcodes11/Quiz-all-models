import { ChevronRight, Zap, ClipboardList, Dumbbell } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Quiz } from "@shared/schema";

interface QuizCardProps {
  quiz: Quiz;
  onStartQuiz: () => void;
}

export default function QuizCard({ quiz, onStartQuiz }: QuizCardProps) {
  const getQuizIcon = (type: string) => {
    switch (type) {
      case "quick":
        return Zap;
      case "mock":
        return ClipboardList;
      case "practice":
        return Dumbbell;
      default:
        return ClipboardList;
    }
  };

  const getQuizIconColor = (type: string) => {
    switch (type) {
      case "quick":
        return "text-ios-blue bg-ios-blue/10";
      case "mock":
        return "text-ios-green bg-ios-green/10";
      case "practice":
        return "text-purple-600 bg-purple-100";
      default:
        return "text-ios-blue bg-ios-blue/10";
    }
  };

  const Icon = getQuizIcon(quiz.type);
  const iconColor = getQuizIconColor(quiz.type);

  return (
    <Button
      onClick={onStartQuiz}
      variant="ghost"
      className="w-full h-auto p-0 bg-white rounded-xl shadow-sm quiz-card hover:shadow-md transition-shadow"
      data-testid={`quiz-card-${quiz.type}`}
    >
      <div className="w-full p-4">
        <div className="flex items-center">
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center mr-4 ${iconColor}`}>
            <Icon className="h-6 w-6" />
          </div>
          <div className="flex-1 text-left">
            <h4 className="font-semibold text-ios-dark" data-testid={`quiz-title-${quiz.type}`}>{quiz.title}</h4>
            <p className="text-sm text-gray-600" data-testid={`quiz-description-${quiz.type}`}>{quiz.description}</p>
          </div>
          <ChevronRight className="h-5 w-5 text-gray-400" />
        </div>
      </div>
    </Button>
  );
}
