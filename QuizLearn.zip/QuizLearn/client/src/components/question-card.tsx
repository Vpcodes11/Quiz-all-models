import { Button } from "@/components/ui/button";
import type { Question } from "@shared/schema";

interface QuestionCardProps {
  question: Question;
  selectedAnswer?: number;
  onAnswerSelect: (answerIndex: number) => void;
}

export default function QuestionCard({ question, selectedAnswer, onAnswerSelect }: QuestionCardProps) {
  const options = Array.isArray(question.options) ? question.options : [];

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div className="p-4">
        <h3 className="text-lg font-semibold text-ios-dark mb-4 leading-relaxed" data-testid="text-question">
          {question.questionText}
        </h3>

        <div className="space-y-3">
          {options.map((option: any, index: number) => (
            <Button
              key={index}
              onClick={() => onAnswerSelect(index)}
              variant="ghost"
              className={`w-full p-4 text-left rounded-xl border-2 transition-all touch-action-manipulation answer-option ${
                selectedAnswer === index
                  ? "border-ios-blue bg-ios-blue/5 selected"
                  : "border-gray-200 hover:border-ios-blue"
              }`}
              data-testid={`answer-option-${index}`}
            >
              <div className="flex items-center">
                <span className="w-6 h-6 rounded-full border-2 border-gray-300 mr-3 flex items-center justify-center">
                  <span 
                    className={`w-3 h-3 rounded-full bg-ios-blue transition-opacity ${
                      selectedAnswer === index ? "opacity-100" : "opacity-0"
                    }`}
                  />
                </span>
                <span className="text-ios-dark">{option.text || option}</span>
              </div>
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}
