import { useLocation } from "wouter";
import { Home, List, TrendingUp, User } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function BottomNavigation() {
  const [location, navigate] = useLocation();

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/quizzes", icon: List, label: "Quizzes" },
    { path: "/progress", icon: TrendingUp, label: "Progress" },
    { path: "/profile", icon: User, label: "Profile" },
  ];

  const isActive = (path: string) => {
    if (path === "/") return location === "/";
    return location.startsWith(path);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 z-40" data-testid="nav-bottom">
      <div className="flex items-center justify-around">
        {navItems.map((item) => (
          <Button
            key={item.path}
            onClick={() => navigate(item.path)}
            variant="ghost"
            className={`flex flex-col items-center py-2 px-4 touch-action-manipulation ${
              isActive(item.path) ? "text-ios-blue" : "text-gray-600"
            }`}
            data-testid={`nav-${item.label.toLowerCase()}`}
          >
            <item.icon className="h-5 w-5 mb-1" />
            <span className="text-xs">{item.label}</span>
          </Button>
        ))}
      </div>
    </nav>
  );
}
