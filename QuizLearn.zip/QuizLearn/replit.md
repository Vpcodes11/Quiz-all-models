# CDS Quiz Application

## Overview

This is a full-stack quiz application built with React, Express, TypeScript, and PostgreSQL. The application provides a mobile-first quiz experience with multiple quiz types (quick MCQ, mock tests, practice mode), real-time scoring, progress tracking, and a modern iOS-inspired interface using shadcn/ui components.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for fast development and building
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management and caching
- **UI Components**: shadcn/ui component library with Radix UI primitives for accessible components
- **Styling**: Tailwind CSS with custom iOS-inspired design tokens and responsive mobile-first approach
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

### Backend Architecture
- **Framework**: Express.js with TypeScript for the REST API server
- **Database ORM**: Drizzle ORM for type-safe database operations and query building
- **Validation**: Zod schemas for runtime type validation and API request/response validation
- **Development**: Hot module replacement via Vite integration for seamless full-stack development
- **Storage Interface**: Abstract storage interface with in-memory implementation for development and easy swapping to database storage

### Data Storage
- **Database**: PostgreSQL as the primary database (configured via Drizzle config)
- **Connection**: Neon Database serverless driver for PostgreSQL connectivity
- **Migrations**: Drizzle Kit for database schema migrations and management
- **Schema**: Comprehensive schema covering users, quizzes, questions, and quiz attempts with proper relationships

### Database Schema Design
- **Users**: Profile information, statistics (total quizzes, average score, streak)
- **Quizzes**: Different types (quick, mock, practice) with configurable time limits and question counts
- **Questions**: Multiple choice questions with JSON-stored options, correct answers, and explanations
- **Quiz Attempts**: Complete attempt records with scores, answers, and timing data

### API Structure
- **RESTful Design**: Standard HTTP methods for CRUD operations
- **Error Handling**: Centralized error handling middleware with proper HTTP status codes
- **Request Logging**: Detailed API request logging with timing and response data
- **Type Safety**: Full TypeScript integration from frontend to backend with shared types

### User Interface Design
- **Mobile-First**: Optimized for touch interactions with iOS-inspired design patterns
- **Navigation**: Bottom navigation bar for primary app sections
- **Quiz Experience**: Card-based question presentation with intuitive answer selection
- **Progress Tracking**: Visual progress indicators and performance analytics
- **Responsive**: Adaptive layout that works across different screen sizes

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form for frontend framework and form management
- **Backend Framework**: Express.js for REST API server with TypeScript support
- **Build Tools**: Vite for fast development builds and TypeScript compilation
- **Router**: Wouter for lightweight client-side routing without React Router complexity

### Database and ORM
- **Drizzle ORM**: Type-safe database operations with PostgreSQL dialect
- **Neon Database**: Serverless PostgreSQL driver for cloud database connectivity
- **Drizzle Kit**: Database migration and schema management tooling

### UI and Styling
- **shadcn/ui**: Complete UI component library built on Radix UI primitives
- **Radix UI**: Accessible, unstyled UI components for complex interactions
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Lucide React**: Icon library for consistent iconography

### Data Management
- **TanStack React Query**: Server state management, caching, and synchronization
- **Zod**: Runtime type validation and schema definition for API contracts
- **date-fns**: Date manipulation and formatting utilities

### Development Tools
- **TypeScript**: Static type checking across the entire application stack
- **PostCSS**: CSS processing with Tailwind CSS integration
- **ESBuild**: Fast JavaScript bundling for production builds

### Replit Integration
- **Replit Plugins**: Development environment integration with error overlay and cartographer
- **Development Banner**: Replit development mode detection and banner display