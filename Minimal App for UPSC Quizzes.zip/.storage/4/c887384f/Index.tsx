import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, Circle, RotateCcw, BookOpen } from 'lucide-react';

// Mock quiz data
const quizData = {
  History: [
    {
      id: 1,
      question: "Who was the first President of India?",
      options: ["Mahatma Gandhi", "Jawaharlal Nehru", "Dr. Rajendra Prasad", "Sardar Patel"],
      correctAnswer: 2
    },
    {
      id: 2,
      question: "The Quit India Movement was launched in which year?",
      options: ["1940", "1942", "1944", "1946"],
      correctAnswer: 1
    },
    {
      id: 3,
      question: "Who founded the Mauryan Empire?",
      options: ["Ashoka", "Chandragupta Maurya", "Bindusara", "Kautilya"],
      correctAnswer: 1
    }
  ],
  Geography: [
    {
      id: 1,
      question: "Which is the longest river in India?",
      options: ["Yamuna", "Godavari", "Ganga", "Krishna"],
      correctAnswer: 2
    },
    {
      id: 2,
      question: "The Western Ghats are also known as?",
      options: ["Sahyadri", "Nilgiris", "Cardamom Hills", "Anamalai"],
      correctAnswer: 0
    },
    {
      id: 3,
      question: "Which state has the longest coastline in India?",
      options: ["Tamil Nadu", "Gujarat", "Maharashtra", "Andhra Pradesh"],
      correctAnswer: 1
    }
  ],
  Polity: [
    {
      id: 1,
      question: "How many fundamental rights are mentioned in the Indian Constitution?",
      options: ["5", "6", "7", "8"],
      correctAnswer: 1
    },
    {
      id: 2,
      question: "Who is known as the Father of Indian Constitution?",
      options: ["Mahatma Gandhi", "B.R. Ambedkar", "Jawaharlal Nehru", "Sardar Patel"],
      correctAnswer: 1
    },
    {
      id: 3,
      question: "The Constitution of India was adopted on?",
      options: ["15 August 1947", "26 January 1950", "26 November 1949", "2 October 1948"],
      correctAnswer: 2
    }
  ],
  Economics: [
    {
      id: 1,
      question: "What does GDP stand for?",
      options: ["Gross Domestic Product", "General Domestic Product", "Government Domestic Product", "Global Domestic Product"],
      correctAnswer: 0
    },
    {
      id: 2,
      question: "The Reserve Bank of India was established in which year?",
      options: ["1934", "1935", "1947", "1950"],
      correctAnswer: 1
    },
    {
      id: 3,
      question: "Which sector contributes the most to India's GDP?",
      options: ["Agriculture", "Manufacturing", "Services", "Mining"],
      correctAnswer: 2
    }
  ],
  "Current Affairs": [
    {
      id: 1,
      question: "Who is the current Chief Justice of India? (As of 2024)",
      options: ["D.Y. Chandrachud", "N.V. Ramana", "S.A. Bobde", "Ranjan Gogoi"],
      correctAnswer: 0
    },
    {
      id: 2,
      question: "G20 Summit 2023 was hosted by which country?",
      options: ["Indonesia", "India", "Italy", "Saudi Arabia"],
      correctAnswer: 1
    },
    {
      id: 3,
      question: "Which mission aims to make India a global hub for green hydrogen?",
      options: ["Mission Hydrogen", "Green India Mission", "National Hydrogen Mission", "Clean Energy Mission"],
      correctAnswer: 2
    }
  ]
};

type Subject = keyof typeof quizData;

export default function UPSCQuizApp() {
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);

  const subjects = Object.keys(quizData) as Subject[];

  const handleSubjectSelect = (subject: Subject) => {
    setSelectedSubject(subject);
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setUserAnswers([]);
    setShowResult(false);
    setQuizCompleted(false);
  };

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNextQuestion = () => {
    if (selectedAnswer !== null && selectedSubject) {
      const newAnswers = [...userAnswers];
      newAnswers[currentQuestion] = selectedAnswer;
      setUserAnswers(newAnswers);

      if (currentQuestion < quizData[selectedSubject].length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
      } else {
        setQuizCompleted(true);
        setShowResult(true);
      }
    }
  };

  const calculateScore = () => {
    if (!selectedSubject) return 0;
    let score = 0;
    userAnswers.forEach((answer, index) => {
      if (answer === quizData[selectedSubject][index].correctAnswer) {
        score++;
      }
    });
    return score;
  };

  const resetQuiz = () => {
    setSelectedSubject(null);
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setUserAnswers([]);
    setShowResult(false);
    setQuizCompleted(false);
  };

  if (!selectedSubject) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-800 mb-2 flex items-center justify-center gap-2">
              <BookOpen className="h-8 w-8 text-blue-600" />
              UPSC Quiz App
            </h1>
            <p className="text-gray-600">Test your knowledge across different subjects</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {subjects.map((subject) => (
              <Card 
                key={subject} 
                className="hover:shadow-lg transition-shadow cursor-pointer hover:scale-105 transform transition-transform"
                onClick={() => handleSubjectSelect(subject)}
              >
                <CardHeader className="text-center">
                  <CardTitle className="text-xl text-blue-700">{subject}</CardTitle>
                  <CardDescription>
                    {quizData[subject].length} Questions
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button className="w-full">Start Quiz</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (showResult) {
    const score = calculateScore();
    const totalQuestions = quizData[selectedSubject].length;
    const percentage = Math.round((score / totalQuestions) * 100);

    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-4">
        <div className="max-w-2xl mx-auto">
          <Card className="text-center">
            <CardHeader>
              <CardTitle className="text-3xl text-green-700">Quiz Complete!</CardTitle>
              <CardDescription className="text-lg">
                Subject: <Badge variant="outline">{selectedSubject}</Badge>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-6xl font-bold text-green-600">
                {score}/{totalQuestions}
              </div>
              <div className="text-2xl text-gray-700">
                {percentage}% Score
              </div>
              <Progress value={percentage} className="w-full h-4" />
              
              <div className="space-y-3">
                <h3 className="text-xl font-semibold text-gray-800">Review Answers:</h3>
                {quizData[selectedSubject].map((question, index) => (
                  <div key={question.id} className="text-left p-4 bg-gray-50 rounded-lg">
                    <p className="font-medium mb-2">{index + 1}. {question.question}</p>
                    <div className="flex items-center gap-2">
                      {userAnswers[index] === question.correctAnswer ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : (
                        <Circle className="h-5 w-5 text-red-600" />
                      )}
                      <span className={`${
                        userAnswers[index] === question.correctAnswer 
                          ? 'text-green-700' 
                          : 'text-red-700'
                      }`}>
                        Your answer: {question.options[userAnswers[index]]}
                      </span>
                    </div>
                    {userAnswers[index] !== question.correctAnswer && (
                      <p className="text-green-700 mt-1">
                        Correct answer: {question.options[question.correctAnswer]}
                      </p>
                    )}
                  </div>
                ))}
              </div>

              <div className="flex gap-4 justify-center">
                <Button onClick={() => handleSubjectSelect(selectedSubject)} className="flex items-center gap-2">
                  <RotateCcw className="h-4 w-4" />
                  Retake Quiz
                </Button>
                <Button variant="outline" onClick={resetQuiz}>
                  Choose Another Subject
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const currentQ = quizData[selectedSubject][currentQuestion];
  const progress = ((currentQuestion + 1) / quizData[selectedSubject].length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <Button variant="outline" onClick={resetQuiz}>← Back to Subjects</Button>
            <Badge variant="secondary" className="text-lg px-4 py-2">{selectedSubject}</Badge>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-gray-600">
              <span>Question {currentQuestion + 1} of {quizData[selectedSubject].length}</span>
              <span>{Math.round(progress)}% Complete</span>
            </div>
            <Progress value={progress} className="w-full" />
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl">
              {currentQ.question}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3">
              {currentQ.options.map((option, index) => (
                <Button
                  key={index}
                  variant={selectedAnswer === index ? "default" : "outline"}
                  className="justify-start text-left h-auto p-4 whitespace-normal"
                  onClick={() => handleAnswerSelect(index)}
                >
                  <span className="font-medium mr-3">{String.fromCharCode(65 + index)}.</span>
                  {option}
                </Button>
              ))}
            </div>

            <div className="flex justify-end pt-4">
              <Button 
                onClick={handleNextQuestion}
                disabled={selectedAnswer === null}
                className="px-8"
              >
                {currentQuestion === quizData[selectedSubject].length - 1 ? 'Finish Quiz' : 'Next Question'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}